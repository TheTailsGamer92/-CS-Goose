if not retroCharAPI then return end

SMB_PINK = retroCharAPI.SMB_PINK
SMB_RED = retroCharAPI.SMB_RED
SMB_WHITE = retroCharAPI.SMB_WHITE
SMB_OFFWHITE = retroCharAPI.SMB_OFFWHITE

function setup_retro_sprites()
    retroCharAPI.add_cs_character_sprites(CT_GOOSE, get_texture_info("goose_0"), get_texture_info("goose_1"))

    retroCharAPI.add_cs_character_palette(CT_GOOSE, {SMB_WHITE, SMB_WHITE, SMB_WHITE}, {SMB_WHITE, SMB_WHITE, SMB_RED}, 1, 2)
end

hook_event(HOOK_ON_MODS_LOADED, setup_retro_sprites)