-- name: [CS] Goose
-- description: HONK!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation

    Use this if you're curious on how anything here works >v<
	(This is an edited version of the Template File by Squishy)
]]

local TEXT_MOD_NAME = "Goose"

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_CUSTOM_MODEL = smlua_model_util_get_id("goose_geo") -- Located in "actors"

local TEX_CUSTOM_LIFE_ICON = get_texture_info("goose_icon") -- Located in "textures"

local E_SOUND_GOOSE = audio_stream_load("goosecs.ogg")

TEX_GOOSE_CS_MENU_GRAFFITI = get_texture_info("graffiti_goose") -- Located in "textures"

-- All Located in "sound" Name them whatever you want. Remember to include the .ogg extension
local VOICETABLE_GOOSE = {
    --[CHAR_SOUND_OKEY_DOKEY] = 'honk.ogg', -- Starting game
	[CHAR_SOUND_LETS_A_GO] = 'honk.ogg', -- Starting level
	[CHAR_SOUND_PUNCH_YAH] = 'honk.ogg', -- Punch 1
	[CHAR_SOUND_PUNCH_WAH] = 'honk.ogg', -- Punch 2
	[CHAR_SOUND_PUNCH_HOO] = 'honk.ogg', -- Punch 3
	[CHAR_SOUND_YAH_WAH_HOO] = {'honk.ogg', 'honk.ogg', 'honk.ogg'}, -- First/Second jump sounds
	[CHAR_SOUND_HOOHOO] = 'honk.ogg', -- Third jump sound
	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'honk.ogg', 'honk.ogg'}, -- Triple jump sounds
	[CHAR_SOUND_UH] = 'honk.ogg', -- Wall bonk
	[CHAR_SOUND_UH2] = 'honk.ogg', -- Landing after long jump
	[CHAR_SOUND_UH2_2] = 'honk.ogg', -- Same sound as UH2; jumping onto ledge
	[CHAR_SOUND_HAHA] = 'honk.ogg', -- Landing triple jump
	[CHAR_SOUND_YAHOO] = 'honk.ogg', -- Long jump
	[CHAR_SOUND_DOH] = 'honk.ogg', -- Long jump wall bonk
	[CHAR_SOUND_WHOA] = 'honk.ogg', -- Grabbing ledge
	[CHAR_SOUND_EEUH] = 'honk.ogg', -- Climbing over ledge
	[CHAR_SOUND_WAAAOOOW] = 'honk.ogg', -- Falling a long distance
	[CHAR_SOUND_TWIRL_BOUNCE] = 'honk.ogg', -- Bouncing off of a flower spring
	[CHAR_SOUND_GROUND_POUND_WAH] = 'honk.ogg', 
	[CHAR_SOUND_HRMM] = 'honk.ogg', -- Lifting something
	[CHAR_SOUND_HERE_WE_GO] = 'honk.ogg', -- Star get
	[CHAR_SOUND_SO_LONGA_BOWSER] = 'honk.ogg', -- Throwing Bowser
--DAMAGE
	[CHAR_SOUND_ATTACKED] = 'honk.ogg', -- Damaged
	[CHAR_SOUND_PANTING] = 'honk.ogg', -- Low health
	[CHAR_SOUND_ON_FIRE] = 'honk.ogg', -- Burned
--SLEEP SOUNDS
	[CHAR_SOUND_IMA_TIRED] = 'honk.ogg', -- Mario feeling tired
	[CHAR_SOUND_YAWNING] = 'honk.ogg', -- Mario yawning before he sits down to sleep
	[CHAR_SOUND_SNORING1] = 'honk.ogg', -- Snore Inhale
	[CHAR_SOUND_SNORING2] = 'honk.ogg', -- Exhale
	[CHAR_SOUND_SNORING3] = 'honk.ogg', -- Sleep talking / mumbling
--COUGHING (USED IN THE GAS MAZE)
	[CHAR_SOUND_COUGHING1] = 'honk.ogg', -- Cough take 1
	[CHAR_SOUND_COUGHING2] = 'honk.ogg', -- Cough take 2
	[CHAR_SOUND_COUGHING3] = 'honk.ogg', -- Cough take 3
--DEATH
	[CHAR_SOUND_DYING] = 'honk.ogg', -- Dying from damage
	[CHAR_SOUND_DROWNING] = 'honk.ogg', -- Running out of air underwater
	[CHAR_SOUND_MAMA_MIA] = 'honk.ogg' -- Booted out of level
}

local CSloaded = false
local function on_character_select_load()
    CT_CHARNAME2 = _G.charSelect.character_add("Goose", {"HONK"}, "Tails Gamer", {r = 255, g = 84, b = 0}, E_MODEL_CUSTOM_MODEL, CT_CHARNAME2, TEX_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_voice(E_MODEL_CUSTOM_MODEL, VOICETABLE_GOOSE)
    _G.charSelect.character_add_celebration_star(E_MODEL_CUSTOM_MODEL, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_menu_instrumental(CT_GOOSE, E_SOUND_GOOSE)
    _G.charSelect.character_add_graffiti(CT_GOOSE, TEX_GOOSE_CS_MENU_GRAFFITI)
    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_GOOSE then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_GOOSE then return _G.charSelect.voice.snore(m) end
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)